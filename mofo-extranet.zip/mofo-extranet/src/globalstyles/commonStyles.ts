import { DefaultPalette, mergeStyles } from 'office-ui-fabric-react/lib/Styling';

import { Theme } from 'spfx-uifabric-themes';

const siteTheme=window.__themeState__.theme;
const webpartTitleStyles=mergeStyles({
    marginBottom:5,
    borderBottomStyle:'solid',
    borderBottomColor:siteTheme.themeLight,
    borderBottomWidth:'thin'   

});



export {webpartTitleStyles,siteTheme}