import * as React from 'react';
import * as ReactDom from 'react-dom';
import * as strings from 'UserInviteMAnagerWebPartStrings';

import { IItem, IItemVersion, List, Web, sp, IWeb } from "@pnp/sp/presets/all";
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import { IUserInviteMAnagerProps } from './components/IUserInviteMAnagerProps';
import UserInviteMAnager from './components/UserInviteMAnager';
import { Version } from '@microsoft/sp-core-library';

export interface IUserInviteMAnagerWebPartProps {
  title: string;
}

export default class UserInviteMAnagerWebPart extends BaseClientSideWebPart<IUserInviteMAnagerWebPartProps> {
  protected onInit(): Promise<void> {
    return super.onInit().then(_ => {
      sp.setup({
       
        spfxContext: this.context
      });
    });
  }
  public render(): void {
    const element: React.ReactElement<IUserInviteMAnagerProps > = React.createElement(
      UserInviteMAnager,
      {
        title: this.properties.title,
        context:this.context,
        displaymode:this.displayMode,
        updateProperty: (value: string) => {
          this.properties.title = value;
          console.log(value);
        }
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('title', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
