import * as React from 'react';
import { Button, PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { IBasePicker, ITag, TagPicker } from 'office-ui-fabric-react/lib/Pickers';
import { IIconProps, Icon } from 'office-ui-fabric-react/lib/Icon';
import { IItem, IItemVersion, List, Web, sp, IWeb } from "@pnp/sp/presets/all";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { IStackItemStyles, IStackStyles, IStackTokens, Stack } from 'office-ui-fabric-react/lib/Stack';

import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';

import { DisplayMode } from '@microsoft/sp-core-library';
import { IUserInviteMAnagerProps } from './IUserInviteMAnagerProps';
import { InviteeItem } from './InviteeItem';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { Link } from 'office-ui-fabric-react/lib/Link';
import { Text } from 'office-ui-fabric-react/lib/Text';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { WebPartTitle } from "@pnp/spfx-controls-react/lib/WebPartTitle";
import { escape } from '@microsoft/sp-lodash-subset';
import { siteTheme } from '../../../globalstyles/commonStyles';
import styles from './UserInviteMAnager.module.scss';
import { webpartTitleStyles } from '../../../globalstyles/commonStyles';
import { FontSizes, IModalProps } from 'office-ui-fabric-react';

const btnNewReqStyles: React.CSSProperties = {
  marginLeft: 'auto'
};
const invSectionStyles: React.CSSProperties = {
  backgroundColor: siteTheme.themeLighterAlt,
  padding: 5, margin: 5
};
const txtInvUsersMess: React.CSSProperties = {
  fontSize: FontSizes.small,
  float: 'right'
};
const modalPropsStyles = { main: { maxWidth: 450 } };
const modalProps: IModalProps = {

}
const dialogContentProps = {
  type: DialogType.normal,
  title: 'Confirm'
};
export interface IUserRequests {
  email: string;
  matters: string[];
}
export interface IInviteeSection {
  inviteeEmails: string;
  selectedMatters: ITag[];
}
export interface IUserInviteMAnagerState {
  matters: ITag[];
  inviteeSections: Array<IInviteeSection>,
  hideDialog: boolean
}

export default class UserInviteMAnager extends React.Component<IUserInviteMAnagerProps, IUserInviteMAnagerState> {
  private web: IWeb;
  constructor(props) {
    super(props);
    this.state = {
      hideDialog: true,
      matters: [],
      inviteeSections: [
        { inviteeEmails: '', selectedMatters: [] as ITag[] }
      ]
    };
    this.web = Web(this.props.context.pageContext.web.absoluteUrl);
  }

  private _picker = React.createRef<IBasePicker<ITag>>();
  private _getTextFromItem(item: ITag): string {
    return item.name;
  }
  private _onFilterChangedNoFilter = (filterText: string, tagList: ITag[]): ITag[] => {
    let matterTags = this.state.matters;
    console.log(matterTags);
    return filterText ? matterTags.filter(tag => tag.name.toLowerCase().indexOf(filterText.toLowerCase()) !== -1) : [];
  };

  private async _updateUPSGuestInvitations(invSections: IInviteeSection[]) {
    let web = this.web;
    let lstName = "UPS Guest Invitations";

    let list = web.lists.getByTitle(lstName);
    const entityTypeFullName = await list.getListItemEntityTypeFullName();

    let batch = web.createBatch();
    list.items.getAll().then(it => console.log(it));

    invSections.forEach(inv => {

      let matters = [];
      inv.selectedMatters.forEach(matter => {
        let matterno = matter.key.split('-', 1)[0].trim();
        matters.push(matterno)
      });

      inv.inviteeEmails.split(';').forEach(em => {

        list.items.inBatch(batch).add({ Title: em, MatterNumbers: matters.toString() }, entityTypeFullName).then(b => {
          console.log(b);
        });

      });

      batch.execute().then(res => console.log(res))

    });

    this.setState({ hideDialog: true });




  }


  componentDidMount() {

    this.web.webinfos.select('Title').get()
      .then(res => {
        let matters = res.map((item) => ({ key: item.Title, name: item.Title }));
        this.setState({
          matters: matters
        });

        console.log(this.state);


      })

  }

  public render(): React.ReactElement<IUserInviteMAnagerProps> {
    const addIcon: IIconProps = { iconName: 'Add' };
    const shareIcon: IIconProps = { iconName: 'Share' };
    const isDraggable = false;

    let { inviteeSections, matters } = this.state;

    let inviteeSectionElements = inviteeSections.map((inv, i) => {
      return (
        <div style={invSectionStyles}>
          <Stack >
            <Stack horizontal>
              <Text>Users</Text>
            </Stack>

            <TextField multiline rows={2} placeholder={'Ex:client1@abc.com;client2@abc.com;client3@abc.com'} value={inv.inviteeEmails} onChange={
              (ev, val) => {
                inviteeSections[i].inviteeEmails = val;
                this.setState({
                  inviteeSections: inviteeSections
                });
              }
            } />
            <Text>Case Numbers</Text>
            <TagPicker
              removeButtonAriaLabel="Remove"
              componentRef={this._picker}
              onChange={items => {

                inviteeSections[i].selectedMatters = items;
                this.setState({
                  inviteeSections: inviteeSections

                });
              }}
              onResolveSuggestions={this._onFilterChangedNoFilter}
              pickerSuggestionsProps={{
                suggestionsHeaderText: 'Suggested Matters',
                noResultsFoundText: 'No Matters Found',
              }}
            />
          </Stack>
        </div>
      )
    })


    return (

      <div className={styles.userInviteMAnager}>
        <div className={styles.container}>
          <WebPartTitle className={webpartTitleStyles} displayMode={this.props.displaymode}
            title={this.props.title}
            updateProperty={this.props.updateProperty} />
          <Stack>
            <Dialog
              hidden={this.state.hideDialog}
              onDismiss={() => this.setState({ hideDialog: true })}
              dialogContentProps={dialogContentProps}
              modalProps={modalProps}
              isBlocking={true}
            >
              <DialogFooter>
                <PrimaryButton onClick={() => {

                  let invSections = this.state.inviteeSections;
                  this._updateUPSGuestInvitations(invSections);


                }
                } text="Send Invites" />
                <DefaultButton onClick={() => this.setState({ hideDialog: true })} text="Cancel" />
              </DialogFooter>
            </Dialog>



            {inviteeSectionElements}
            <Stack>
              <div style={btnNewReqStyles}> <Link onClick={ev => {
                  console.log(inviteeSections);
                let newSection = {} as IInviteeSection;
                this.setState({
                  inviteeSections: inviteeSections.concat(newSection)
                });
                console.log(inviteeSections);

              }
              }>+ Add New</Link></div>
              <div > <PrimaryButton iconProps={shareIcon} onClick={
                e => {
                  console.log(this.state.inviteeSections);
                 this.setState({
                   hideDialog:false
                 })
                 

                }
              }  >Invite Users</PrimaryButton></div>
            </Stack>
          </Stack>

        </div>
      </div>
    );
  }
  
}
