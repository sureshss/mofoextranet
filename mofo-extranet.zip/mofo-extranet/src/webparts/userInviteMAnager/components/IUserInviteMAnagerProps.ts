import { DisplayMode } from '@microsoft/sp-core-library';
import { IWebPartContext } from '@microsoft/sp-webpart-base';

export interface IUserInviteMAnagerProps {
  title: string;
  displaymode:DisplayMode;  
  updateProperty (value: string):any;
  context:IWebPartContext
}
