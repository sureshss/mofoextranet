import * as React from 'react';

import { Button, PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import { IBasePicker, ITag, TagPicker } from 'office-ui-fabric-react/lib/Pickers';
import { IIconProps, Icon } from 'office-ui-fabric-react/lib/Icon';
import { IItem, IItemVersion, List, Web, sp } from "@pnp/sp/presets/all";
import { IStackItemStyles, IStackStyles, IStackTokens, Stack, StackItem } from 'office-ui-fabric-react/lib/Stack';

import { Link } from 'office-ui-fabric-react/lib/Link';
import { Text } from 'office-ui-fabric-react/lib/Text';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { siteTheme } from '../../../globalstyles/commonStyles';

const btnNewReqStyles: React.CSSProperties = {
  marginLeft: 'auto'
};

const stackAlignmentstyles: IStackStyles = {

}
const addIcon: IIconProps = { iconName: 'Add' };
const shareIcon: IIconProps = { iconName: 'Share' };
const stackTokens: IStackTokens = {
  childrenGap: 10
};
const stackItemStyles: IStackItemStyles = {
  root: {
    display: 'flex',   
    width: '50%'
  }
};
const stackStyles: IStackStyles = {
  root: {
    background: siteTheme.themeTertiary
  }
};
export const InviteeItem = () => {
  return (
    <div >
      <Stack horizontal styles={stackStyles} tokens={stackTokens}>
        <Stack.Item grow styles={stackItemStyles}>
          <Text>Users</Text>
          <TextField multiline rows={3} />
        </Stack.Item>
        <Stack.Item grow styles={stackItemStyles}>
          Grow is 2
      </Stack.Item>

      </Stack>


    </div>
  )
}