declare interface IUserInviteMAnagerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UserInviteMAnagerWebPartStrings' {
  const strings: IUserInviteMAnagerWebPartStrings;
  export = strings;
}
