declare interface IMyClientMattersWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MyClientMattersWebPartStrings' {
  const strings: IMyClientMattersWebPartStrings;
  export = strings;
}
