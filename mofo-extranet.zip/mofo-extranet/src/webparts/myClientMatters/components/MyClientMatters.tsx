import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/polyfill-ie11";
import { DefaultPalette, mergeStyles } from 'office-ui-fabric-react/lib/Styling';
import { INavLink, Nav } from 'office-ui-fabric-react/lib/Nav';
import { ISearchBoxStyles, SearchBox } from 'office-ui-fabric-react/lib/SearchBox';
import { IStackItemStyles, IStackStyles, IStackTokens, Stack } from 'office-ui-fabric-react/lib/Stack';
import { IWeb, IWebInfo, IWebInfosData, Web, Webs } from '@pnp/sp/webs';

import { DisplayMode } from '@microsoft/sp-core-library';
import { IMyClientMattersProps } from './IMyClientMattersProps';
import { Link } from 'office-ui-fabric-react/lib/Link';
import { Theme } from 'spfx-uifabric-themes';
import { WebPartTitle } from "@pnp/spfx-controls-react/lib/WebPartTitle";
import { escape } from '@microsoft/sp-lodash-subset';
import { itemStyles } from "../../caseSummary/components/Styles";
import { loadTheme } from 'office-ui-fabric-react';
import {siteTheme} from '../../../globalstyles/commonStyles';
import { sp } from "@pnp/sp";
import styles from './MyClientMatters.module.scss';
import {webpartTitleStyles} from '../../../globalstyles/commonStyles'

const stackItemStyles = mergeStyles({
  alignItems: 'center',
  display: 'flex',
  height: 25,
  textAlign: 'left'
});
const stackStyles: React.CSSProperties = {
  height:500,
  backgroundColor:window.__themeState__.theme.bodyBackground,
  overflowY:'scroll'
};
const searchBoxStyles: Partial<ISearchBoxStyles> = { root: { width: 300 } };
const numericalSpacingStackTokens: IStackTokens = {
  childrenGap: 5
};
const matterLinkStyles = mergeStyles({
  color: window.__themeState__.theme.neutralPrimary
});

export default class MyClientMatters extends React.Component<IMyClientMattersProps, { webs: IWebInfosData[],filteredWebs:IWebInfosData[] }> {
  constructor(props) {
    super(props);
    this.state = {
      webs: [],
      filteredWebs:[]
    }
  }
  componentDidMount() {

    sp.web.webinfos.get()
      .then(webs => {
        console.log(webs)
        this.setState({
          webs: webs,
          filteredWebs:webs
        })
      })

  }
  public render(): React.ReactElement<IMyClientMattersProps> {
    let {webs,filteredWebs} = this.state;

    console.log(filteredWebs);
    let matWebElements =
    filteredWebs.map((matter: IWebInfosData) => {
        return (
          <span className={stackItemStyles}>
            <Link className={matterLinkStyles} href={matter.ServerRelativeUrl} target="_blank">{matter.Title}</Link>
          </span>
        )
      });
    return (

      <div className={styles.myClientMatters}>
        <div className={styles.container}>
          <WebPartTitle className={webpartTitleStyles} displayMode={this.props.displaymode}
            title={this.props.title}
            updateProperty={this.props.updateProperty} />
          <SearchBox
            styles={searchBoxStyles}
            placeholder="Search"           
            onChange={ev=>{
              let filterWebs= webs.filter(web=>web.Title.toLocaleLowerCase().includes(ev.toLowerCase()));
              this.setState({filteredWebs:filterWebs})

            }}
            onSearch={ev=>{
              let filterWebs= webs.filter(web=>web.Title.toLocaleLowerCase().includes(ev.toLowerCase()));
              this.setState({filteredWebs:filterWebs})

            }}
           
          />

          <Stack  tokens={numericalSpacingStackTokens}>
            <div style={stackStyles}> 
            {matWebElements}
            </div>
          </Stack>
        </div>
      </div>
    );
  }
}
