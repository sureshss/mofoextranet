declare interface ICaseSummaryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CaseSummaryWebPartStrings' {
  const strings: ICaseSummaryWebPartStrings;
  export = strings;
}
