

import * as React from 'react';
import * as ReactDom from 'react-dom';
import * as strings from 'CaseSummaryWebPartStrings';
import "@pnp/polyfill-ie11";
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { DisplayMode, Version } from '@microsoft/sp-core-library';

import CaseSummary from './components/CaseSummary';
import {Helper} from '../../helper/Helper';
import { ICaseSummaryProps } from './components/ICaseSummaryProps';
import { sp } from "@pnp/sp/presets/all";

export interface ICaseSummaryWebPartProps {
  title: string; 
  
}
const currenttheme= window.__themeState__.theme;

export default class CaseSummaryWebPart extends BaseClientSideWebPart<ICaseSummaryWebPartProps> {
  protected onInit(): Promise<void> {
    return super.onInit().then(_ => {
      sp.setup({
        spfxContext: this.context
      });
    });
  }
  getMatterNumberFromUrl():string{
    let weburl = this.context.pageContext.web.serverRelativeUrl;
    let urlsplit: string[] = weburl.split('/');  
    return urlsplit[urlsplit.length - 1]
  }
  public render(): void {
    const element: React.ReactElement<ICaseSummaryProps > = React.createElement(
      CaseSummary,
      {

        title: this.properties.title,
        matterNumber:this.getMatterNumberFromUrl(),
        context:this.context,
        displaymode:this.displayMode,   
        updateProperty: (value: string) => {
          this.properties.title = value;
        }
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('title', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
