
import * as React from 'react';
import "@pnp/polyfill-ie11";
import {
  Button,
  DefaultButton,
  DefaultPalette,
  IStackItemStyles,
  IStackStyles,
  IStackTokens,
  Link,
  Separator,
  SeparatorBase,
  Stack,
  StackItem,
  Text,
  mergeStyles
} from '../../../helper/OfficeFabricExports';
import { IItem, IItemVersion, List, Web, sp } from "@pnp/sp/presets/all";
import {headerseperator, itemStyles, linkStyles, stackStyles, summaryStyle, summaryStyles, verticalGapStackTokens} from './Styles';
import { objectDefinedNotNull, objectToMap, stringIsNullOrEmpty } from '@pnp/common';

import CaseTrackerDetails from './CaseTrackerDetails';
import Constants from "../../../helper/Constants";
import { Helper } from '../../../helper/Helper';
import { ICaseSummaryProps } from './ICaseSummaryProps';
import { ICaseTracker } from '../../../Interfaces/ICaseTracker';
import { IPlaintiff } from '../../../Interfaces/IPlaintiff';
import PlaintiffDetails from './PlaintiffDetails';
import ScaleLoader from "react-spinners/ScaleLoader";
import { WebPartTitle } from "@pnp/spfx-controls-react/lib/WebPartTitle";
import { css } from "@emotion/core";
import { escape } from '@microsoft/sp-lodash-subset';
import isEmpty from 'lodash/isEmpty';
import styles from './CaseSummary.module.scss';
import { webpartTitleStyles } from '../../../globalstyles/commonStyles'

const override = css`
  display: block;
  margin: 0 auto;
  border-color: red;
`;
export interface IMatter {
  Id: string;
  Title: string;
}
export default class CaseSummary extends React.Component<ICaseSummaryProps, {
  casetracker: ICaseTracker, plaintiff: IPlaintiff, additionalPlaintiffs: IPlaintiff[]
}> {
  constructor(props) {
    super(props);
    this.state = {
      casetracker: {} as ICaseTracker,     
      plaintiff: {} as IPlaintiff,
      additionalPlaintiffs: []
    }
  }

 
  async getMatterDetails() {
    
    let matterno = this.props.matterNumber;
    let matter = await sp.site.rootWeb.lists.getByTitle('UPS Matter Numbers').items.top(1)
      .filter(`Title eq '${this.props.matterNumber}'`).get();
    let matterid = matter[0].ID;

    let matterDetails = await sp.site.rootWeb.lists.getByTitle('Case Tracker').items.top(1)
      .filter(`UPSMatterNumberId eq '${matterid}'`).get();
      console.log(matterDetails);

      let plaintiffDetails = await sp.site.rootWeb.lists.getByTitle('Plaintiff').items
      .filter(`UPSMatterNumberId eq '${matterid}'`).get();
      console.log(plaintiffDetails);

      let mainPlaintiff = plaintiffDetails.find((pl: IPlaintiff) => {
        return pl.MainPlaintiff == 'Yes'
      });
      let addPlaintiffs = plaintiffDetails.filter((pl: IPlaintiff) => {
        return pl.MainPlaintiff !== 'Yes'
      });


      this.setState({
        casetracker:matterDetails[0],
        plaintiff:mainPlaintiff,
        additionalPlaintiffs:addPlaintiffs
      })

      console.log(this.state);




  }

  
  componentDidMount() {  
    console.log('111111111111111111111111111')
    this.getMatterDetails();
  }
  public render(): React.ReactElement<ICaseSummaryProps> {
    const { casetracker, plaintiff, additionalPlaintiffs } = this.state;
    let weburl = this.props.context.pageContext.web.absoluteUrl;
    let caseitemUrl = `https://${window.location.host}${Constants.castrackerListUrl}/EditForm.aspx?ID=${casetracker.ID}&Source=${weburl}`;


    let isrender = (casetracker !== undefined && plaintiff !== undefined && !isEmpty(casetracker) && !isEmpty(plaintiff)  ) ? true : false;


    return (
      <div className={styles.caseSummary}>
        {
          isrender ?
            <div className={styles.container}>
              <CaseTrackerDetails matternumber={this.props.matterNumber} caseitemUrl={caseitemUrl} weburl={weburl} casetracker={casetracker} plaintiff={plaintiff} />
              <Stack><div className={headerseperator}></div></Stack>
              <PlaintiffDetails weburl={weburl}
                additionalPlaintiffs={additionalPlaintiffs} plaintiff={plaintiff} />
            </div> :
            <ScaleLoader
              css={override}
              color={window.__themeState__.theme.themePrimary}
              loading={true}
            />
        }
      </div>
    );
  }
}
