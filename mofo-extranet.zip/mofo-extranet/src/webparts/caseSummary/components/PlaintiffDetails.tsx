
import * as React from 'react';
import {
  Button,
  DefaultButton,
  DefaultPalette,
  IStackItemStyles,
  IStackStyles,
  IStackTokens,
  Link,
  Separator,
  SeparatorBase,
  Stack,
  StackItem,
  Text,
  mergeStyles
} from '../../../helper/OfficeFabricExports';

import {
  classLabels,
  headerseperator,
  itemStyles,
  linkStyles,
  stackStyles,
  summaryStyle,
  summaryStyles,
  verticalGapStackTokens
} from './Styles';

import Constants from "../../../helper/Constants";
import { Helper } from '../../../helper/Helper';
import { IPlaintiff } from '../../../Interfaces/IPlaintiff';

export interface IPlaintiffProps{
  plaintiff:IPlaintiff;weburl:string;additionalPlaintiffs:IPlaintiff[]
}
const PlaintiffDetails=(props:IPlaintiffProps)=>{
  let  {plaintiff,weburl,additionalPlaintiffs}={...props};
  console.log(additionalPlaintiffs);
 let addPlaintiffs= additionalPlaintiffs.map(pl=>{
    let addplurl=`https://${window.location.host}${Constants.plaintiffListUrl}/EditForm.aspx?ID=${pl.ID}&Source=${weburl}`;  
    return(
     <Stack> <Link href={addplurl} style={linkStyles}>{pl.Title}</Link></Stack>
    )
  })
  
  let itemurl=`https://${window.location.host}${Constants.plaintiffListUrl}/EditForm.aspx?ID=${plaintiff.ID}&Source=${weburl}`;
    return(
        <Stack styles={stackStyles} tokens={verticalGapStackTokens}>
        <div><b>Plaintiff Snapshot | Update Plaintiff Details: </b> 
          <Link href={itemurl} style={linkStyles}>{plaintiff.Title}</Link>
        </div>       
        <Stack>
          <div style={itemStyles}><b style={classLabels}>Named Plaintiff:</b> {`${Helper.GetFieldValue(plaintiff.Title)}`}</div>         
        </Stack>
        <Stack horizontal >
          <div ><b style={classLabels}>Additional Plaintiffs:</b></div> 
          <div>{addPlaintiffs}</div>         
        </Stack>
        <Stack >
          <div> <b style={classLabels}>Plaintiff's Council:</b>{`${plaintiff.Counsel}`}</div>         
        </Stack>
        <Stack horizontal styles={stackStyles}  >
          <div style={itemStyles}> <b style={classLabels}>Employment Category:</b>{`${Helper.GetFieldValue(plaintiff.EmploymentCategory)}`}</div>
          <div style={itemStyles}><b style={classLabels}>Last Position:</b>{` ${Helper.GetFieldValue(plaintiff.LastPosition)}`}</div>
          <div />
        </Stack>
        <Stack horizontal styles={stackStyles}  >
          <div style={itemStyles}><b style={classLabels}>Hire Date:</b> {`${Helper.GetDateValue(plaintiff.HireDate)}`}</div>
          <div style={itemStyles}><b style={classLabels}>Term Date:</b>{`${Helper.GetDateValue(plaintiff.TermDate)}`}</div>
          <div />
        </Stack>

        <Stack horizontal styles={stackStyles}  >
          <div style={itemStyles}><b style={classLabels}>District Name:</b>{`${Helper.GetFieldValue(plaintiff.DistrictName)}`}</div>
          <div style={itemStyles}><b style={classLabels}>Work Location: </b>{`${Helper.GetFieldValue(plaintiff.Work)}`}</div>
          <div />
        </Stack>
        
      </Stack>

    )
}
export default PlaintiffDetails;