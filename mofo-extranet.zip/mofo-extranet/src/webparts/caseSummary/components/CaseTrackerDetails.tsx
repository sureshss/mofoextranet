import * as React from 'react';

import {
    Button,
    DefaultButton,
    DefaultPalette,
    IStackItemStyles,
    IStackStyles,
    IStackTokens,
    Link,
    Separator,
    SeparatorBase,
    Stack,
    StackItem,
    Text,
    mergeStyles
} from '../../../helper/OfficeFabricExports';
import { classLabels, itemStyles, linkStyles, stackStyles, summaryStyle, summaryStyles, verticalGapStackTokens } from './Styles';
import { objectDefinedNotNull, objectToMap, stringIsNullOrEmpty, } from '@pnp/common'

import Constants from "../../../helper/Constants";
import { Helper } from '../../../helper/Helper';
import { ICaseTracker } from '../../../Interfaces/ICaseTracker';
import { IPlaintiff } from '../../../Interfaces/IPlaintiff';

export interface ICaseProps {
    caseitemUrl: string, casetracker: ICaseTracker, plaintiff: IPlaintiff, weburl: string,matternumber:string
}
const CaseTrackerDetails = (props: ICaseProps) => {
    
    let { caseitemUrl, casetracker, plaintiff, weburl ,matternumber} = { ...props }
   
  
    return (
           
        <Stack styles={stackStyles} tokens={verticalGapStackTokens}>
            <div><b style={classLabels}>Case Snapshot as of:</b>{Helper.GetDateValue(casetracker.Modified)} <b>| Update Case Details:  </b>
                <Link href={caseitemUrl} style={linkStyles}>{matternumber + ' - ' + plaintiff.Title}</Link>
            </div>
            <Stack horizontal styles={stackStyles}  >
                <div style={itemStyles}> <b style={classLabels}>Date Filed: </b>{`${Helper.GetDateValue(casetracker.DateFiled)}`}</div>
                <div style={itemStyles}><b style={classLabels}>Class Limitations Period: </b>{`${Helper.GetDateValue(casetracker.ClassLimitationPeriod)}`}</div>
                <div />
            </Stack>
            <Stack horizontal styles={stackStyles}  >
                <div style={itemStyles}> <b style={classLabels}>Case Type: </b>{`${Helper.GetFieldValue(casetracker.CaseType)}`}</div>
                <div style={itemStyles}><b style={classLabels}>PAGA Limitations Period:</b>{`${Helper.GetDateValue(casetracker.PAGALimitationsPeriod)}`}</div>
                <div />
            </Stack>
            <Stack horizontal styles={stackStyles}  >
                <div style={itemStyles}> <b style={classLabels}>UPS Defendant (Legal Entity):</b>{`${Helper.GetFieldValue(casetracker.UPS_x0020_DefendantLegalEntity)}`}</div>
                <div style={itemStyles}><b style={classLabels}>Pleaded Class Definitions: </b>{`${Helper.GetFieldValue(casetracker.PleadedClassDefinition)}`}</div>
                <div />
            </Stack>
            <Stack horizontal styles={stackStyles}  >
                <div style={itemStyles}> <b style={classLabels}>UPS Counsel:</b>{`${Helper.GetFieldValue(casetracker.UPSOutsideCounsel)}`}</div>
                <div style={itemStyles}><b style={classLabels}>Actual Class Definitions:</b>{`${Helper.GetFieldValue(casetracker.ActualClassDefinition)}`}</div>
                <div />
            </Stack>

            <Stack horizontal styles={stackStyles}  >
                <div style={itemStyles}><b style={classLabels}>Stage: </b>{`${Helper.GetFieldValue(casetracker.Stage)}`}</div>
                <div style={itemStyles}><b style={classLabels}>State:</b>{`${Helper.GetFieldValue(casetracker.State)}`}</div>
                <div />
            </Stack>
            <Stack >
                <div ><b style={classLabels}>Primary Theory of Recovery:</b>{`${Helper.GetFieldValue(casetracker.PrimaryTheoryofRecovery)}`}</div>
            </Stack>
            <Stack horizontal>
            <b style={classLabels}> Summary:</b> 
        <div style={summaryStyle} contentEditable={false} dangerouslySetInnerHTML={{ __html: casetracker.CaseStatusSummary }}></div>
            </Stack>
            <Stack horizontal>
            <b style={classLabels}>In-House Comments:</b>
               
        <div style={summaryStyle} contentEditable={false} dangerouslySetInnerHTML={{ __html: casetracker.InHouseComments }}></div>
            </Stack>
           
            <Stack>
            </Stack>
        </Stack>

    )
}
export default CaseTrackerDetails;