import { DefaultPalette, mergeStyles } from 'office-ui-fabric-react/lib/Styling';
import { IStackItemStyles, IStackStyles, IStackTokens, Stack } from 'office-ui-fabric-react/lib/Stack';

import {siteTheme} from '../../../globalstyles/commonStyles';

const verticalGapStackTokens: IStackTokens = {
  childrenGap: 10
};

const stackStyles: IStackStyles = {
  root: {
    background: siteTheme.bodyBackground,
  },
};
const itemStyles: React.CSSProperties = {
  alignItems: 'left',
  display: 'flex',
  width: '40%',
  paddingRight: 5
};
const summaryStyles: React.CSSProperties = {
  fontStyle: 'italic',
  fontFamily: 'Segoe UI Light WestEuropean,Segoe UI Light,Segoe WP Light,Segoe UI,Segoe WP,Tahoma,Arial,sans-serif',
  fontSize: 20,
  marginTop: 10,
  borderBottomStyle: 'solid',
  borderBottomColor: window.__themeState__.theme.themeLight,
  borderBottomWidth: 'thin',
  borderTopStyle: 'solid',
  borderTopColor: window.__themeState__.theme.themeLight,
  borderTopWidth: 'thin'
};
const summaryStyle: React.CSSProperties = {
  paddingLeft: 2
}
const linkStyles: React.CSSProperties = {
 
  marginRight:5

};
const headerseperator=mergeStyles({
    marginBottom:5,
    borderBottomStyle:'solid',
    borderBottomColor:siteTheme.themeLight,
    borderBottomWidth:'thin'
   
  });
  const classLabels:React.CSSProperties={
    paddingRight:5
  }
export {linkStyles,headerseperator,classLabels,summaryStyles,summaryStyle,itemStyles,stackStyles,verticalGapStackTokens}