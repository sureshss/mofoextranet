const Constant={
    castrackerListUrl:'/sites/UPSCaseTracker/Lists/Case%20Details',
    plaintiffListUrl:'/sites/UPSCaseTracker/Lists/Plaintiff',
    castrackerList:'Case Tracker',
    plaintiffList:'Plaintiff'



}
export default Constant;