import format from 'date-fns/format'

class Helper {
  static GetFieldValue(value: any): string {
   
    if (value !== null && value !==undefined ) {
      return value;
    } else {
      return "";
    }
  }
  static GetDateValue(value: any): string {
    
    if (value !== null && value !==undefined) {
      let date=format(new Date(value), 'MM/dd/yyyy')
      return date;
    } else {
      return "";
    }
  }
}

export {Helper}