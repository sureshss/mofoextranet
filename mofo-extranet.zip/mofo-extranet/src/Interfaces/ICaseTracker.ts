export interface ICaseTracker {
                
    FileSystemObjectType:             number;
    Id:                               number;
    ServerRedirectedEmbedUri:         string;
    ServerRedirectedEmbedUrl:         string;
    Title:                            string;
    DisplayMatterId:                 number;
    DisplayMatter:                    string;
    UPS_x0020_DefendantLegalEntity:   string[];
    AdditionalDefendants:             string;
    DateFiled:                        Date;
    ClassLimitationPeriod:                 string;
    PleadedClassDefinition:           string[];
    ActualClassDefinition:            string;
    ClassDescription:                 string;
    ClaimType:                        string;
    PrimaryTheoryofRecovery:   string[];
    CaseType:                         string;
    MatterDescription:                string;
    UPSOutsideCounsel:                string[];
    District_x0020_:                  string;
    Jurisdiction:                     string;
    SettlementAmount:                 string;
    Court:                            string;
    CaseNumber:                       string;
    CaseName:                         string;
    State:                            string;
    Judge:                            string;
    RemovedtoFederalCourt:            string;
    DateofRemoval:                    string;
    Stage:                            string;
    Disposition:                      string;
    NextEvent:                        string;
    NextEventDate:                    Date;
    UnionInformation:                 string;
    ClassSize_x0020_:                 string;
    Notes:                            string;
    Calendar:                         Calendar;
    LegalHoldIssued:                  boolean;
    DistrictTitle:                    string;
    ClaimTypesTitle:                  string[];
    ClaimTypeTitle:                   string;
    CaseStatusSummary:                string;
    InHouseComments:                  string;
    UPSAttorney:                      string[];
    Status:                           string;
    PAGALimitationsPeriod:  string;
    Plaintiff_x0020_Counsel:          string;
    ContentTypeId:                    string;
    ComplianceAssetId:                string;
    ID:                               number;
    Modified:                         Date;
    Created:                          Date;
    AuthorId:                         number;
    EditorId:                         number;
    OData__UIVersionString:           string;
    Attachments:                      boolean;
    GUID:                             string;
    PlaintiffInfoId:string;
}

export interface Calendar {
    Description: string;
    Url:         string;
}
