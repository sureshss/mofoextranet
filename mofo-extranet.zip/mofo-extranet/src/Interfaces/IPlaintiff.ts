export interface IPlaintiff {   
    NamedPlaintiff:string;
    PlaintiffInfoId:string;
    AdditionalPlaintiffs:string;
    FileSystemObjectType: number;
    Id: number;
    ServerRedirectedEmbedUri?: any;
    ServerRedirectedEmbedUrl: string;
    ContentTypeId: string;
    Title: string;
    ComplianceAssetId?: any;
    Counsel: string;
    EmploymentCategory: string;
    LastPosition: string;
    HireDate: Date;
    TermDate: Date;
    MainPlaintiff:string;
    LOA: string;
    Work: string;
    Managers: string;
    HRRep: string;
    EmployeeType: string;
    RegionName: string;
    DistrictName: string;
    FacilityCode: string;
    FacilityDisplay: string;
    UPSMatterNumber: string;
    DisplayMatter: string;
    ID: number;
    Modified: Date;
    Created: Date;
    AuthorId: number;
    EditorId: number;
    OData__UIVersionString: string;
    Attachments: boolean;
    GUID: string;
}


