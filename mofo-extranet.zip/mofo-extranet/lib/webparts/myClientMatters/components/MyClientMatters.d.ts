import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/polyfill-ie11";
import { IWebInfosData } from '@pnp/sp/webs';
import { IMyClientMattersProps } from './IMyClientMattersProps';
export default class MyClientMatters extends React.Component<IMyClientMattersProps, {
    webs: IWebInfosData[];
    filteredWebs: IWebInfosData[];
}> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IMyClientMattersProps>;
}
//# sourceMappingURL=MyClientMatters.d.ts.map