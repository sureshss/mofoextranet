declare const styles: {
    myClientMatters: string;
    container: string;
};
export default styles;
//# sourceMappingURL=MyClientMatters.module.scss.d.ts.map