import { BaseClientSideWebPart, IPropertyPaneConfiguration } from "@microsoft/sp-webpart-base";
import { DisplayMode, Version } from "@microsoft/sp-core-library";
export interface IMyClientMattersWebPartProps {
    title: string;
    displaymode: DisplayMode;
    updateProperty(value: string): any;
}
export default class MyClientMattersWebPart extends BaseClientSideWebPart<IMyClientMattersWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=MyClientMattersWebPart.d.ts.map