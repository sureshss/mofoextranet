import "@pnp/polyfill-ie11";
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
import { Version } from '@microsoft/sp-core-library';
export interface ICaseSummaryWebPartProps {
    title: string;
}
export default class CaseSummaryWebPart extends BaseClientSideWebPart<ICaseSummaryWebPartProps> {
    protected onInit(): Promise<void>;
    getMatterNumberFromUrl(): string;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=CaseSummaryWebPart.d.ts.map