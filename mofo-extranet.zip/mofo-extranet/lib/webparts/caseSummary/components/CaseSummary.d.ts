import * as React from 'react';
import "@pnp/polyfill-ie11";
import { ICaseSummaryProps } from './ICaseSummaryProps';
import { ICaseTracker } from '../../../Interfaces/ICaseTracker';
import { IPlaintiff } from '../../../Interfaces/IPlaintiff';
export interface IMatter {
    Id: string;
    Title: string;
}
export default class CaseSummary extends React.Component<ICaseSummaryProps, {
    casetracker: ICaseTracker;
    plaintiff: IPlaintiff;
    additionalPlaintiffs: IPlaintiff[];
}> {
    constructor(props: any);
    getMatterDetails(): Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<ICaseSummaryProps>;
}
//# sourceMappingURL=CaseSummary.d.ts.map