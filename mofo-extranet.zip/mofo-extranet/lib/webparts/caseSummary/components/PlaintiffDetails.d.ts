/// <reference types="react" />
import { IPlaintiff } from '../../../Interfaces/IPlaintiff';
export interface IPlaintiffProps {
    plaintiff: IPlaintiff;
    weburl: string;
    additionalPlaintiffs: IPlaintiff[];
}
declare const PlaintiffDetails: (props: IPlaintiffProps) => JSX.Element;
export default PlaintiffDetails;
//# sourceMappingURL=PlaintiffDetails.d.ts.map