/// <reference types="react" />
import { IStackStyles, IStackTokens } from 'office-ui-fabric-react/lib/Stack';
declare const verticalGapStackTokens: IStackTokens;
declare const stackStyles: IStackStyles;
declare const itemStyles: React.CSSProperties;
declare const summaryStyles: React.CSSProperties;
declare const summaryStyle: React.CSSProperties;
declare const linkStyles: React.CSSProperties;
declare const headerseperator: string;
declare const classLabels: React.CSSProperties;
export { linkStyles, headerseperator, classLabels, summaryStyles, summaryStyle, itemStyles, stackStyles, verticalGapStackTokens };
//# sourceMappingURL=Styles.d.ts.map