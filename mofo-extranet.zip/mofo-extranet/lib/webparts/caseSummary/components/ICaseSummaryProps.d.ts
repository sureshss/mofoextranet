import { DisplayMode } from "@microsoft/sp-core-library";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface ICaseSummaryProps {
    title: string;
    matterNumber: string;
    context: WebPartContext;
    displaymode: DisplayMode;
    updateProperty(value: string): any;
}
//# sourceMappingURL=ICaseSummaryProps.d.ts.map