declare const styles: {
    caseSummary: string;
    container: string;
};
export default styles;
//# sourceMappingURL=CaseSummary.module.scss.d.ts.map