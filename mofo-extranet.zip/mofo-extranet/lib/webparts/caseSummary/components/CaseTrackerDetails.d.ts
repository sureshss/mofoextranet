/// <reference types="react" />
import { ICaseTracker } from '../../../Interfaces/ICaseTracker';
import { IPlaintiff } from '../../../Interfaces/IPlaintiff';
export interface ICaseProps {
    caseitemUrl: string;
    casetracker: ICaseTracker;
    plaintiff: IPlaintiff;
    weburl: string;
    matternumber: string;
}
declare const CaseTrackerDetails: (props: ICaseProps) => JSX.Element;
export default CaseTrackerDetails;
//# sourceMappingURL=CaseTrackerDetails.d.ts.map