import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
import { Version } from '@microsoft/sp-core-library';
export interface IUserInviteMAnagerWebPartProps {
    title: string;
}
export default class UserInviteMAnagerWebPart extends BaseClientSideWebPart<IUserInviteMAnagerWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=UserInviteMAnagerWebPart.d.ts.map