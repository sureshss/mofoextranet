declare const styles: {
    userInviteMAnager: string;
    container: string;
};
export default styles;
//# sourceMappingURL=UserInviteMAnager.module.scss.d.ts.map