import * as React from 'react';
import { ITag } from 'office-ui-fabric-react/lib/Pickers';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { IUserInviteMAnagerProps } from './IUserInviteMAnagerProps';
export interface IUserRequests {
    email: string;
    matters: string[];
}
export interface IInviteeSection {
    inviteeEmails: string;
    selectedMatters: ITag[];
}
export interface IUserInviteMAnagerState {
    matters: ITag[];
    inviteeSections: Array<IInviteeSection>;
    hideDialog: boolean;
}
export default class UserInviteMAnager extends React.Component<IUserInviteMAnagerProps, IUserInviteMAnagerState> {
    private web;
    constructor(props: any);
    private _picker;
    private _getTextFromItem;
    private _onFilterChangedNoFilter;
    private _updateUPSGuestInvitations;
    componentDidMount(): void;
    render(): React.ReactElement<IUserInviteMAnagerProps>;
}
//# sourceMappingURL=UserInviteMAnager.d.ts.map