/// <reference types="react" />
export declare const InviteeItem: () => JSX.Element;
//# sourceMappingURL=InviteeItem.d.ts.map