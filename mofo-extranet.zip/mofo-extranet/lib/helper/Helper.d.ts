declare class Helper {
    static GetFieldValue(value: any): string;
    static GetDateValue(value: any): string;
}
export { Helper };
//# sourceMappingURL=Helper.d.ts.map