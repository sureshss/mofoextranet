declare const Constant: {
    castrackerListUrl: string;
    plaintiffListUrl: string;
    castrackerList: string;
    plaintiffList: string;
};
export default Constant;
//# sourceMappingURL=Constants.d.ts.map