import { Theme } from 'spfx-uifabric-themes';
declare const siteTheme: Theme;
declare const webpartTitleStyles: string;
export { webpartTitleStyles, siteTheme };
//# sourceMappingURL=commonStyles.d.ts.map